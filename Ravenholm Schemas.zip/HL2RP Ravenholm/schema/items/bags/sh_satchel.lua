-- Item Statistics

ITEM.name = "Satchel"
ITEM.description = "A small bag."

-- Item Configuration

ITEM.model = "models/willardnetworks/clothingitems/satchel.mdl"
ITEM.skin = 0

-- Item Inventory Size Configuration

ITEM.width = 2
ITEM.height = 1

ITEM.invWidth = 3
ITEM.invHeight = 2
