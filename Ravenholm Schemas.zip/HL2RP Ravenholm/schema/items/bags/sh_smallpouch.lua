-- Item Statistics

ITEM.name = "Small Pouch"
ITEM.description = "A small Pouch. Featuring small compartments for storage of items."

-- Item Configuration

ITEM.model = "models/willardnetworks/skills/surgicalkit.mdl"
ITEM.skin = 0

-- Item Inventory Size Configuration

ITEM.width = 2
ITEM.height = 1

ITEM.invWidth = 3
ITEM.invHeight = 2
