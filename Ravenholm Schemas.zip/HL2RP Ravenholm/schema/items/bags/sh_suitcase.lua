-- Item Statistics

ITEM.name = "Suitcase"
ITEM.description = "A small suitcase."

-- Item Configuration

ITEM.model = "models/weapons/w_suitcase_passenger.mdl"
ITEM.skin = 0

-- Item Inventory Size Configuration

ITEM.width = 2
ITEM.height = 2

ITEM.invWidth = 3
ITEM.invHeight = 2
