-- Item Statistics

ITEM.name = "7.62x39mm Rifle Bullets"
ITEM.description = "A Box that contains %s of Rifle Ammo"
ITEM.category = "Ammo"

-- Item Configuration

ITEM.model = "models/willardnetworks/skills/explosive_material.mdl"
ITEM.skin = 0

-- Item Inventory Size Configuration

ITEM.width = 1
ITEM.height = 1

-- Item Custom Configuration

ITEM.ammo = "ar2"
ITEM.ammoAmount = 60
ITEM.bDropOnDeath = true
