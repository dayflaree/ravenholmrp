CLASS.name = "Conscript (Combine)"
CLASS.description = "A conscript which is sent to the coast near the Raveholm Town to keep guard or commence raids."
CLASS.faction = FACTION_CONSCRIPT
CLASS.isDefault = false

CLASS_CONSCRIPT_C = CLASS.index
