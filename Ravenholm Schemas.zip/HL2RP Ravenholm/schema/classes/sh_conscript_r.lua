CLASS.name = "Conscript (Rebel)"
CLASS.description = "A conscript which has gone rogue."
CLASS.faction = FACTION_CONSCRIPT
CLASS.isDefault = false

CLASS_CONSCRIPT_R = CLASS.index