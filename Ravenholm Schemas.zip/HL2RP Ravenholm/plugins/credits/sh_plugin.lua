local PLUGIN = PLUGIN

PLUGIN.name = "Credits"
PLUGIN.description = "Adds a command to roll the credits for all players."
PLUGIN.author = "Riggs"

PLUGIN.speed = 48 -- How fast the credits roll. (default: 48)
PLUGIN.killTime = 80 -- Time in seconds to wait before killing the credits.
PLUGIN.musicTrack = "music/vlvx_song3.mp3" -- MUST BE A VALID SOUND FILE
PLUGIN.credits = [[
<font=Font-Elements32>
Framework Used
</font><font=Font-Elements24>
<color=115,53,142>helixβ</color>
</font>

<font=Font-Elements32>
<color=50,100,200>Developers</color>
</font><font=Font-Elements24>
Riggs - Lead Developer
eon (bloodycop) - Assistant Developer
</font>

<font=Font-Elements64>
Thank You For Playing
</font>
]]

if ( CLIENT ) then
    concommand.Add("ix_credits", function()
        vgui.Create("ixNewCredits")
    end)

    concommand.Add("ix_credits_music", function()
        local credits = vgui.Create("ixNewCredits")
        credits.musicEnabled = true
    end)
end

ix.command.Add("credits", {
    description = "Roll the credits for all players.",
    superAdminOnly = true,
    arguments = {
        bit.bor(ix.type.bool, ix.type.optional),
    },
    OnRun = function(self, ply, bMusic)
        for k, v in pairs(player.GetAll()) do
            if ( bMusic ) then
                v:ConCommand("ix_credits_music")
            else
                v:ConCommand("ix_credits")
            end
        end
    end
})
