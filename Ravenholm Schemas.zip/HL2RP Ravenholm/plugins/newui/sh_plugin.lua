local PLUGIN = PLUGIN

PLUGIN.name = "New UI"
PLUGIN.description = "A new UI, to replace the old helix framework UI."
PLUGIN.author = "Riggs"