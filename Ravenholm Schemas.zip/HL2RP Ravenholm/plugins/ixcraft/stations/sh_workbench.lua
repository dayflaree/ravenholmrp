
STATION.name = "General Workbench"
STATION.description = "A workbench used for crafting."
STATION.model = "models/willardnetworks/skills/craftingstation.mdl"
