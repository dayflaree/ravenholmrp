
STATION.name = "Stove"
STATION.description = "A stove used for cooking."
STATION.model = "models/mosi/fallout4/furniture/workstations/cookingstation01.mdl"
