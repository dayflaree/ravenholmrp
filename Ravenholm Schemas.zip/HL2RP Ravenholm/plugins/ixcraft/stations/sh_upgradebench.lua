
STATION.name = "Upgrade & Repair Workbench"
STATION.description = "A workbench used for upgrading and repairing weapons and armor."
STATION.model = "models/mosi/fallout4/furniture/workstations/armorworkbench.mdl"
