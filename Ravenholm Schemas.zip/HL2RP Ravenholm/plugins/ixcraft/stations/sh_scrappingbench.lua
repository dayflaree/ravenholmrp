STATION.name = "Scrapping Workbench"
STATION.description = "A workbench used for scrapping weapons and items."
STATION.model = "models/mosi/fallout76/furniture/workstations/tinkerstation.mdl"
