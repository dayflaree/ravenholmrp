
STATION.name = "Tailoring Workbench"
STATION.description = "A workbench used for crafting clothing and armor."
STATION.model = "models/mosi/fallout4/furniture/workstations/weaponworkbench02.mdl"
