
STATION.name = "Weapon Workbench"
STATION.description = "A workbench used for crafting weapons and tools."
STATION.model = "models/mosi/fallout4/furniture/workstations/weaponworkbench01.mdl"
