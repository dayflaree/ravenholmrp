local PLUGIN = PLUGIN

PLUGIN.name = "Helios Outfits"
PLUGIN.description = "Fixes some issues with Helix's builtin outfit system."
PLUGIN.author = "Helios"