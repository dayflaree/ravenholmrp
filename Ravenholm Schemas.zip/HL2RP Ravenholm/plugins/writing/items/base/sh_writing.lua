
ITEM.name = "Writing Base"
ITEM.model = Model("models/props_c17/paper01.mdl")
ITEM.description = "Something that can be written on."
ITEM.category = "Tools"
