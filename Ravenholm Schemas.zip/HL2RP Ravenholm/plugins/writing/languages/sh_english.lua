
LANGUAGE = {
    paper = "Paper"
}
