-- Item Statistics

ITEM.name = "Metal Ingot"
ITEM.description = "A chunk of metal."
ITEM.category = "Resources"

-- Item Configuration

ITEM.model = "models/willard/work/silveringot.mdl"
ITEM.skin = 0

ITEM.illegal = true

-- Item Inventory Size Configuration

ITEM.width = 2
ITEM.height = 1
