-- Item Statistics

ITEM.name = "Chunk of Plastic"
ITEM.description = "A small chunk of scrap plastic."
ITEM.category = "Miscellaneous"

-- Item Configuration

ITEM.model = "models/props_c17/canisterchunk01a.mdl"
ITEM.skin = 0

-- Item Inventory Size Configuration

ITEM.width = 1
ITEM.height = 1

-- Item Custom Configuration

ITEM.maxStacks = 20