-- Item Statistics

ITEM.name = "Electronics"
ITEM.description = "Some electronic parts."
ITEM.category = "Miscellaneous"

-- Item Configuration

ITEM.model = "models/props/cs_office/projector_p6.mdl"
ITEM.skin = 0

-- Item Inventory Size Configuration

ITEM.width = 1
ITEM.height = 1

-- Item Custom Configuration

ITEM.maxStacks = 16