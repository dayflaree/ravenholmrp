-- Item Statistics

ITEM.name = "Wood"
ITEM.model = "models/items/item_item_crate_chunk02.mdl"
ITEM.category = "Miscellaneous"

-- Item Configuration

ITEM.model = "models/items/item_item_crate_chunk02.mdl"
ITEM.skin = 0

-- Item Inventory Size Configuration

ITEM.width = 1
ITEM.height = 1

-- Item Custom Configuration

ITEM.maxStacks = 32