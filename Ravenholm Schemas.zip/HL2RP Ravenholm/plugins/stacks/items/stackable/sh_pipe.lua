-- Item Statistics

ITEM.name = "Metal Pipe"
ITEM.description = "A metal pipe."
ITEM.category = "Miscellaneous"

-- Item Configuration

ITEM.model = "models/props_lab/pipesystem03a.mdl"
ITEM.skin = 0

-- Item Inventory Size Configuration

ITEM.width = 1
ITEM.height = 1

-- Item Custom Configuration

ITEM.maxStacks = 16