-- Item Statistics

ITEM.name = "Refined Metal Plate"
ITEM.description = "A refined metal plate."
ITEM.category = "Miscellaneous"

-- Item Configuration

ITEM.model = "models/gibs/scanner_gib02.mdl"
ITEM.skin = 0

-- Item Inventory Size Configuration

ITEM.width = 1
ITEM.height = 1

-- Item Custom Configuration

ITEM.maxStacks = 24