-- Item Statistics

ITEM.name = "Metal Gear"
ITEM.description = "A small metal gear."
ITEM.category = "Miscellaneous"

-- Item Configuration

ITEM.model = "models/props_wasteland/gear02.mdl"
ITEM.skin = 0

-- Item Inventory Size Configuration

ITEM.width = 1
ITEM.height = 1

-- Item Custom Configuration

ITEM.maxStacks = 16