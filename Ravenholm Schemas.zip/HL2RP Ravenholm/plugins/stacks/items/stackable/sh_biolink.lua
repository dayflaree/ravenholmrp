-- Item Statistics

ITEM.name = "Destroyed Biolink"
ITEM.description = "An Destroyed Biolink from an Metropolice Unit."
ITEM.category = "Miscellaneous"

-- Item Configuration

ITEM.model = "models/gibs/manhack_gib03.mdl"
ITEM.skin = 0

-- Item Inventory Size Configuration

ITEM.width = 1
ITEM.height = 1

-- Item Custom Configuration

ITEM.maxStacks = 16