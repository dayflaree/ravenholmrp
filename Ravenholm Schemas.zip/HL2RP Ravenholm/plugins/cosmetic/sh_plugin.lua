local PLUGIN = PLUGIN

PLUGIN.name = "Cosmetics"
PLUGIN.description = "Ported the cosmetics system from impulse framework."
PLUGIN.author = "Vin"

ix.util.Include("cl_cosmetic.lua")