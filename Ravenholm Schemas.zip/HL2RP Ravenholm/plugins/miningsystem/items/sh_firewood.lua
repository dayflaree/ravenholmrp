-- Item Statistics

ITEM.name = "Fire wood"
ITEM.description = "A piece of fire wood."
ITEM.category = "Mining Resources"

-- Item Configuration

ITEM.model = "models/props_foliage/tree_slice_chunk01.mdl"
ITEM.skin = 0

-- Item Inventory Size Configuration

ITEM.width = 1
ITEM.height = 1
