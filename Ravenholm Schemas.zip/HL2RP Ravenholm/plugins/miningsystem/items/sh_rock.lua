-- Item Statistics

ITEM.name = "Rock"
ITEM.description = "A rock, it's pretty heavy."
ITEM.category = "Mining Resources"

-- Item Configuration

ITEM.model = "models/props_junk/rock001a.mdl"
ITEM.skin = 0

ITEM.illegal = false

-- Item Inventory Size Configuration

ITEM.width = 1
ITEM.height = 1