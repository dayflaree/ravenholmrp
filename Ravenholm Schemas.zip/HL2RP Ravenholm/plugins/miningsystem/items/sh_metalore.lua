-- Item Statistics

ITEM.name = "Metal Ore"
ITEM.description = "A chunk of metal ore."
ITEM.category = "Mining Resources"

-- Item Configuration

ITEM.model = "models/props_mining/rock_caves01b.mdl"
ITEM.skin = 0

-- Item Inventory Size Configuration

ITEM.width = 1
ITEM.height = 1
