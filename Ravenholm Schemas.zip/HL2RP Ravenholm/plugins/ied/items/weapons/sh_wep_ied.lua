ITEM.name = "IED"
ITEM.description = "An IED which can be used to bomb yourself."
ITEM.model = "models/weapons/w_c4.mdl"
ITEM.class = "ix_ied"
ITEM.weaponCategory = "gear"
ITEM.width = 1
ITEM.height = 1