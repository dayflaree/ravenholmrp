local PLUGIN = PLUGIN

PLUGIN.name = "Deployables"
PLUGIN.description = "Adds deployable items for the combine."
PLUGIN.author = "Riggs"

ix.util.Include("sv_hooks.lua")
ix.util.Include("sv_plugin.lua")