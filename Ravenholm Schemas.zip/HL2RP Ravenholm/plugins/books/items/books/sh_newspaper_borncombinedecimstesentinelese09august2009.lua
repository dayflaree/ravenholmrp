ITEM.name = "Born! Newsletter: The Combine Ruthlessly Decimate Sentinelese Tribe"
ITEM.model = Model("models/props_c17/paper01.mdl")
ITEM.description = "An issue of the illegal Born! Newsletter, dated for Sunday 9th August 2009."
ITEM.price = 10

ITEM.text = [[
<font color='red' size='4'>Written by 'Gandhi'.</font>

The Alien occupiers have committed yet another brutal atrocity that cannot be ignored.

The Sentinelese were a primitive uncontacted people who inhabited the Sentinel Islands. They have always been content to remain on their Island and have ways displayed hostility towards intruders. Their only ever contact with outsiders were the Imperial British, who killed two of their tribesmen. They have feared and driven off outsiders ever since

The CWU had a ship that passed by the Sentinel Islands. It was allegedly damaged by a Hydra and anchored in the sea to await repairs. A handful of crewmen went ashore in search of fresh water, but were driven off by the Sentinelese. Tragically, two of the CWU were killed.

The Combine were not content to accept that these primitive people were likely terrified by the intruders from the strange metal monster and thus they must shoulder some responsibility. No, the Combine remain convinced that they are the rightful overlords of all humans as if we were their chattel. They sent the dreaded Overwatch Transhuman Arm to the Island and put the place to the torch.

We know not how many died that day, but we know of a few survivors who were captured by the Combine. What the fate of these poor captives, amongst them young children, will be is unknown. We can scarecly begin to imagine the pain and fear these people must have.

This cannot be tolerated. People of Earth, the Combine are a brutal and tyrannical overlord who have shown that they will wipe out entire communities for the offences of individuals. Resist them while you can. 
]]