ITEM.name = "Resist!"
ITEM.model = Model("models/props_c17/paper01.mdl")
ITEM.description = "A call to arms!"
ITEM.price = 10

ITEM.text = [[
<font color='red' size='4'>Written by a free man.</font>

Resist!

People of Earth, don't be fooled by the Combine's lies! They seek to put you to sleep with golden promises: by when you wake, all that we had will be gone- stolen!

Do not listen to them! Stand up and fight to be free, cast off the shackles of the combine and embrace your humanity!

And for those of you who inform on your brothers or serve the enemy, remember this quote!
"First they came for the Socialists, and I did not speak out—
Because I was not a Socialist.

Then they came for the Trade Unionists, and I did not speak out— 
Because I was not a Trade Unionist.

Then they came for the Jews, and I did not speak out— 
Because I was not a Jew.

Then they came for me—and there was no one left to speak for me.""

Make no mistake, the Combine are coming for you too. Stand now, while there is still someone left to stand with you. 
Do what you can to disrupt their rule. Heroes come in all shapes, you don't need a gun. Help your fellow citizens, frustrate the Combine's efforts, work slower! Nobody can chose your level of participation, but everyone can choose to participate.
]]