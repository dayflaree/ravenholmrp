ITEM.name = "Born! Newsletter: The Combine Use Headcrabs as Bioweapons"
ITEM.model = Model("models/props_c17/paper01.mdl")
ITEM.description = "An issue of the illegal Born! Newsletter, dated for Thursday 18th December 2008."
ITEM.price = 10

ITEM.text = [[
<font color='red' size='4'>Written by 'Napoleon'.</font>

Long before the Combine, many of the world countries had come together to lay down rules for warfare, which included the banning and restricting of inhumane weapons of war, usually chemical weapons and incendiary weapons and the sorts.

None of these weapons were anything as terrible as what the combine now unleash on us. Headcrabs, a threat the Combine has allowed to persist as a new part of our ecosystem, refusing to purge them from the Earth (and with some even having found their way into the cities), will now rain down in metal shells on anyone who dares to question the combine. 

A refugee camp in the outlands were the first victims of these new terrible weapons. One of the survivors, a young man we will refer to as Robert , describes it as
"... There were five of them . At first we thought it was artillery, that the shells weren't detonating properly... And we were relieved... For all the damage they caused, we were just happy to be alive... Then the shells opened up, and headcrabs leapt out. It took us off guard... "

Of the 32 refugees in this small camp, thirteen escaped with their lives. The rest were either turned into zombies or turn apart by their former friends and family. The psychological effect of these weapons far outstrips their lethality. These are weapons of terror, designed to frighten us into submission.

We will not submit.

People of Earth, we cannot allow this to continue. We must stop this barbarity. 
]]