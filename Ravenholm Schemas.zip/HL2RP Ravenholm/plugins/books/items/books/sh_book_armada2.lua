ITEM.name = "Armada, Segment 2"
ITEM.model = Model("models/props_lab/binderbluelabel.mdl")
ITEM.description = "A segment of a book called 'Armada'. The other pages seem to be missing."
ITEM.price = 62

ITEM.text = [[
The event.

The event was horrendous. On December 8th 2004, a foreign species invaded earth and began to destroy us one by one.

Ryan saw this as an opportunity. I saw this as the end.

On this day, I immediately saw the news that strange beings are beginning to invade earth. I thought this was a joke
at first. Some random bullshit ad or something for Christmas that is coming up. But no, it wasn't. It was not a joke
at all. For about the first two hours, I saw military forces setting up on my neighborhood, evacuating people they said to
Russia. I do not know why we were going to Russia, my damn house was fine. The skies were clear except for helicopters
and large planes. There was a military checkpoint towards the outer border of the city on my street, and to the right was
incoming trooper vehicles and people moving in towards the city. I quickly ran back into my house, packed my things,
and yelled for Ryan. No response. I ran into his room to see that his rifle and old service equipment was gone. I realized
what he was doing. He was going to pretend to be a soldier so he can get the action.

I didn't bother look for Ryan. It was too fast. I had to get my stuff and get to the city. I could only take a backpack's
worth of items because the entire freeway was completely covered in abandoned cars. People figured running was faster than
waiting for the accidents up ahead to clear. I biked inbetween the cars, and it was an eerie feeling. I saw the occasional
group of people running towards the city, but where did everyone go?

By the time I made it to the airport, the entire place was packed and there were enormous lines leading from outside the damn
building. There was no way I was getting on a plane to Russia, so I had to think of a different plan. The military
said they reccomended civilians to either get to the airport or for people to get to the Government Fallout Shelter.
I decided to run for the shelter, when somehow, I found Ryan watching civilians line up and ensuring that they were
lined up. He actually looked like a soldier, like he belonged there. I did not intervene or say hello. Instead,
I high-tailed it to the Government Fallout Shelter and by the time I made it, it was too late. In the center of the city,
a tower so high that it reached the clouds, just appeared in the middle of the city. It was extremely tall and dark,
and creatures alike were pouring out from the slits of it flying around and shooting down government helicopters. I
tried to get into the shelter but they locked me out. So, I ran back to my house and grabbed whatever I could and barricaded
my house. That did not stop them from getting in.

Ten futuristic looking soldiers rushed up to my house with strange assault rifles. They just put a bomb on my door
and everything went flying back. They then aimed their rifles at me and I surrendered. They were wearing blue
gear and had weird masks on that would glow a blue hue. They had a perfect posture and had tremendous strength, as I learned
when they literally picked me up like a damn stick and carried me to their holding cell. I sat in there for days,
just waiting for something to happen. But then, one of them came up to me and threw me in an interrogation room.
They asked me for military or police experience. I told them I had none of that, and they said that was good. They then
assigned me as a 'Metro-Police Officer' or whatever the fuck. They gave me their weird masks and a strange uniform, and put
me through training that seemed like it was for marines. After I was assigned, they said I was in-charge of Precinct 4 and
protecting the citizens. I wondered what that meant, but I just shrugged it off. I was given a weird stick that had
an electrical end, and they told me that if people did not follow the law, I was to beat them.

I immediately snuck off to my house the minute I was let out, and by the time I got there, it was completely empty.
My TV, Computer, Bed, Oven, Couches, everything. Completely empty. I thought maybe someone stole them, but then I learned
that these aliens were scrapping everything on this earth and taking our resources. I did not see any familiar faces
for a long time, but one year later, I saw Ryan wearing a blue suit like the rest of the citizens. He was being
punished for drug abuse with severe beatings. I intervened and told them to stop and 'let me handle it'. Ryan, afraid for his
life, begged me for mercy, and I granted it. I took off my helmet and let him see my face. His frown turned to an immediate
smile and he hugged me, shivering and bleeding from the torture he had received earlier. I pretended to hurt him
more, then let him go. He said that he wanted to join the Resistance or whatever. I thought about doing it too, but
I had begun to develop a strange sense of authority, and a sense that I was better than that damn resistance. The aliens
were turning me into a damn war machine for them.

I never saw Ryan again after that, but I learned about what he did. About a year later, the airport that we thought would never
work again got a passenger plane flown into it. The Combine Soldiers were immediately dispatched and searched the plane.
About 200 US Soldiers were on that plane, ready to fight. They killed all the Combine Soldiers, and I surrendered. I saw
the Resistance come and handcuff me, and they began to torture me. I said that I did not wish to be in the Union, but
they forced me to. I told them about Ryan, and they told me that he called the plane over here and died to an overdose.
He called Mason and they came to rescue everyone here, but in about a few hours, they were all killed, including Mason.
I watched my family and friends die, yet I still served for the Union.

Ryan fought like an Armada.
]]