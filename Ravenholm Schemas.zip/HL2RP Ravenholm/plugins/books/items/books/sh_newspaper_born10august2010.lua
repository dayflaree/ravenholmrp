ITEM.name = "Born! Newsletter: The Combine Murder and Destroy in Sichuan"
ITEM.model = Model("models/props_c17/paper01.mdl")
ITEM.description = "An issue of the illegal Born! Newsletter, dated for 10th August 2010."
ITEM.price = 10

ITEM.text = [[
<font color='red' size='4'>Written by 'White Rose'.</font>

The Alien occupiers have committed yet another brutal atrocity in the form of violent excess. 

A large number of refugee communities as well as Civil Centres existed along the Yalong River in the former China, now known as Sector Seven. 

Several days ago, the Planetary Liberation Army, a large scale resistance organisation in Sector 7 who has dedicated themselves to protection and serving other humans and refugees in need and who will be best recognised by many for their efforts in establishing and running the Sector 7 railroad, were attacked by the Combine at Ertan Dam. 

These brave heroes, however, stood defiant against the overwhelming odds that were brought against them and killed countless scores of soldiers and synthetic allies. By the end of the first day of fighting, they had wiped out a full half of the Combines assault force and had dug in. Allegedly, they had even captured a Combine Administrator Zhang Cao whose train had foolishly attempted to travel through the scene of the battle and been forced to stop! 


The Combine, ever brutal and excessive, destroyed the dam in the fighting with no regard for the consequences of their actions outside of the battle. The waters rushed down and drowned many of the brave PLA heroes, including their leader Wang Dongfen. Zhang Cao was barely rescued from the flooding himself, with his injuries now being passed off by the Combine as the results of 'torture' at the hands of the PLA, a terrible smear. 

The water, however, flooded onwards. Thousands drowned in the ensuing torrent that washed over many peaceful refugee camps, reports even suggest that some synths and Combine soldiers were also caught in the flooding and killed, and a number of Civil Centres operated by the Combine themselves have received widespread damage. 

Rationing has been tightened in response to a loss of food and farmland, but I implore you dear reader, to consider how an alien empire with seemingly limitless resources when it comes to military occupation and conquest is completely unable to give proper relief aid to those afflicted by famine? 


This cannot be tolerated. People of Earth, the Combine are a brutal and tyrannical overlord who have shown they don't even care for their own citizens and soldiers, let alone the many innocents who have fallen prey to them. They will happily destroy entire towns of innocents to kill their foes. Resist them while you can. 
]]
