ITEM.name = "The Times Newspaper Exclusive: EARTH SURRENDERS!"
ITEM.model = Model("models/props_junk/garbage_newspaper001a.mdl")
ITEM.description = "The final newspaper released by The Times before they were absorbed into the Combine ran Terminal Newspaper, dated 4th September 2001."
ITEM.price = 10

ITEM.text = [[
<font color='red' size='4'>Written by Tony Douglas.</font>

Today, the UN announced the final surrender of mankind, effectively immediately. All remaining military personnel have been ordered to stand down. In but seven hours, we have been humiliated and crushed. Perhaps all that can be said in trade for the fate of our soldiers is that our surrender is confirmed to be a conditional one.
Doctor Wallace Breen, former administrator of Black Mesa, led a UN entourage to contact the alien entity which we can now confirm refers to itself as the Universal Union. The UN Secretary General has confirmed that one of the primary conditions of our surrender is annexation into this Union as a client species. What this means for mankind is unclear.
I need not dwell on the destructive capabilities of our new overlords. Many of us have seen it first hand. What I have been asked to say by the UN regards the other technological innovations which, as I understand, were demonstrated to Doctor Breen and the United Nations. Amongst them include near limitless potential for clean energy generation and medical tecchnology beyond our wildest dreams, which they have promised to share with us as part of the 'upliftment'.
I have also been asked by Doctor Breen to clarify that the war was never the Universal Unions intent. It would appear that our soldiers, fearful for their lives, took to firing upon the envoys of the new alien contact during their attempts to contact us and in doing so inadvertently declared war. 
While we have no confirmation of what the changes will our lives and world will be under the Universal Union, it will doubtless be sweeping and dramatic. Already, the United Nations is being reformed into the 'Earth Civil Administration', an organisation which will form the basis for a new government. Time will tell what our new found place within this Union will bring us.
I urge you all to hope for the best- and to be ready for the worst.
]]
