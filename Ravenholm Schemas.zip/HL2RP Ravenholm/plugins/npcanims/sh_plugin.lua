local PLUGIN = PLUGIN

PLUGIN.name = "NPC Animations"
PLUGIN.author = "Skay"
PLUGIN.description = "Adds animations to NPC's."

ix.util.Include("sv_plugin.lua")