-- Item Statistics

ITEM.name = "Ramen"
ITEM.description = "Charity's favorite."
ITEM.category = "Food"
ITEM.model = "models/willardnetworks/food/noodles.mdl"

-- Item Inventory Size Configuration

ITEM.width = 1
ITEM.height = 1

-- Item Custom Configuration

ITEM.useTime = 2
ITEM.useSound = "litenetwork/eat.wav"
ITEM.restoreHunger = 20